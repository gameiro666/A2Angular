import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-felipe-home',
  templateUrl: './felipe-home.component.html',
  styleUrls: ['./felipe-home.component.css']
})
export class FelipeHomeComponent implements OnInit {
  
  
  constructor() { }


  ngOnInit() {
  }

}